#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vec4 finalColor = Color;

    if (Color.r > 0.49 && Color.r < 0.51 && Color.g > 0.99 && Color.b > 0.12 && Color.b < 0.13) {
        finalColor = vec4(1.0, 0.15, 0.15, Color.a);
    }

    if (Color.r < 0.15 && Color.g < 0.15 && Color.b < 0.15 && Color.a > 0.0) {
        finalColor = vec4(0.2, 0.02, 0.02, Color.a);
    }

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    
    vertexColor = finalColor * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}